package anthony.SuperCraftBrawl.playerdata;

import java.sql.ResultSet;

public interface ExecuteFunction {
	void execute(ResultSet set);
}
