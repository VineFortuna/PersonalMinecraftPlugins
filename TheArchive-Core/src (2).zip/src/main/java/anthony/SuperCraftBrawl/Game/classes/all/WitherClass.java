package anthony.SuperCraftBrawl.Game.classes.all;

import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.Inventory;

import anthony.SuperCraftBrawl.Game.GameInstance;
import anthony.SuperCraftBrawl.Game.classes.BaseClass;
import anthony.SuperCraftBrawl.Game.classes.ClassType;

public class WitherClass extends BaseClass{

	public WitherClass(GameInstance instance, Player player) {
		super(instance, player);
		// TODO Auto-generated constructor stub
	}

	@Override
	public ClassType getType() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void SetArmour(EntityEquipment playerEquip) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void SetNameTag() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void SetItems(Inventory playerInv) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void UseItem(PlayerInteractEvent event) {
		// TODO Auto-generated method stub
		
	}

}
