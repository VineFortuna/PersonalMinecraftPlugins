package anthony.SuperCraftBrawl.Game.classes;

import org.bukkit.entity.Player;

import anthony.SuperCraftBrawl.Game.GameInstance;
import anthony.SuperCraftBrawl.Game.classes.all.BabyCowClass;
import anthony.SuperCraftBrawl.Game.classes.all.BatClass;
import anthony.SuperCraftBrawl.Game.classes.all.BunnyClass;
import anthony.SuperCraftBrawl.Game.classes.all.ButterBroClass;
import anthony.SuperCraftBrawl.Game.classes.all.ButterGolemClass;
import anthony.SuperCraftBrawl.Game.classes.all.Cactus;
import anthony.SuperCraftBrawl.Game.classes.all.ChickenClass;
import anthony.SuperCraftBrawl.Game.classes.all.DarkSethBling;
import anthony.SuperCraftBrawl.Game.classes.all.EnderdragonClass;
import anthony.SuperCraftBrawl.Game.classes.all.EndermanClass;
import anthony.SuperCraftBrawl.Game.classes.all.GhastClass;
import anthony.SuperCraftBrawl.Game.classes.all.HerobrineClass;
import anthony.SuperCraftBrawl.Game.classes.all.HorseClass;
import anthony.SuperCraftBrawl.Game.classes.all.IrongolemClass;
import anthony.SuperCraftBrawl.Game.classes.all.NinjaClass;
import anthony.SuperCraftBrawl.Game.classes.all.SatermelonClass;
import anthony.SuperCraftBrawl.Game.classes.all.SethBlingClass;
import anthony.SuperCraftBrawl.Game.classes.all.SheepClass;
import anthony.SuperCraftBrawl.Game.classes.all.SkeletonClass;
import anthony.SuperCraftBrawl.Game.classes.all.SlimeClass;
import anthony.SuperCraftBrawl.Game.classes.all.SnowGolemClass;
import anthony.SuperCraftBrawl.Game.classes.all.SnowmanClass;
import anthony.SuperCraftBrawl.Game.classes.all.SpiderClass;
import anthony.SuperCraftBrawl.Game.classes.all.SquidClass;
import anthony.SuperCraftBrawl.Game.classes.all.TNTClass;
import anthony.SuperCraftBrawl.Game.classes.all.WitchClass;
import net.md_5.bungee.api.ChatColor;

public enum ClassType {

	Cactus(1, 0), TNT(2, 350), Enderdragon(3, 0), Skeleton(4, 0), Ninja(5, 2500), IronGolem(6, 0), Enderman(7, 0),
	Ghast(8, 0), Chicken(9, 500), Slime(10, 0), ButterGolem(11, 0), DarkSethBling(12, 150), Witch(13, 1000),
	SnowGolem(14, 800), Bat(15, 0), SethBling(16, 0), Sheep(17, 550), Horse(18, 0), Melon(19, 0),
	/* Rabbit, */ Squid(20, 0), Spider(21, 0), BabyCow(22, 0), Herobrine(23, 0), Bunny(24, 450), ButterBro(25, 1200), Snowman(26, 0);

	private int id;
	private int tokenCost = 0;
	private Player player;

	private ClassType(int id, int tokenCost) {
		this.id = id;
		this.tokenCost = tokenCost;
	}

	private ClassType(Player player) {
		this.player = player;
	}

	public int getID() {
		return id;
	}

	public int getTokenCost() {
		return tokenCost;
	}

	public static ClassType fromID(int id) {
		for (ClassType ct : ClassType.values()) {
			if (ct.getID() == id) {
				return ct;
			}
		}
		return null;
	}

	public BaseClass GetClassInstance(GameInstance instance, Player player) {
		switch (this) {
		case Cactus:
			return new Cactus(instance, player);
		case Snowman:
			return new SnowmanClass(instance, player);
		case Enderdragon:
			return new EnderdragonClass(instance, player);
		case Skeleton:
			return new SkeletonClass(instance, player);
		case TNT:
			return new TNTClass(instance, player);
		case Ninja:
			return new NinjaClass(instance, player);
		case IronGolem:
			return new IrongolemClass(instance, player);
		case Enderman:
			return new EndermanClass(instance, player);
		case Ghast:
			return new GhastClass(instance, player);
		case Herobrine:
			return new HerobrineClass(instance, player);
		case Chicken:
			return new ChickenClass(instance, player);
		case Slime:
			return new SlimeClass(instance, player);
		case ButterGolem:
			return new ButterGolemClass(instance, player);
		case DarkSethBling:
			return new DarkSethBling(instance, player);
		case Witch:
			return new WitchClass(instance, player);
		case SnowGolem:
			return new SnowGolemClass(instance, player);
		case Bat:
			return new BatClass(instance, player);
		case SethBling:
			return new SethBlingClass(instance, player);
		case Sheep:
			return new SheepClass(instance, player);
		case Horse:
			return new HorseClass(instance, player);
		case Melon:
			return new SatermelonClass(instance, player);
		case ButterBro:
			return new ButterBroClass(instance, player);
		/*
		 * case Rabbit: return new RabbitClass(instance, player);
		 */
		case Squid:
			return new SquidClass(instance, player);
		case Spider:
			return new SpiderClass(instance, player);
		case BabyCow:
			return new BabyCowClass(instance, player);
		case Bunny:
			return new BunnyClass(instance, player);
		}
		return null;
	}

	public String getClassDesc() {
		switch (this) {
		case Cactus:
			return "A pricklyyy living thing, made up of thornws & blood..";
		case Snowman:
			return "This is a Snowman, not a SnowGolem. Get it right pleb!";
		case Skeleton:
			return "A long range shooter effective at taking down their targets";
		case Enderdragon:
			return "Jump higher than your opponents and teleport around!";
		case Enderman:
			return "Stare into the souls of your enemies whilst teleporting around them";
		case Horse:
			return "Nayyy!! Different effects = different powers!";
		case Squid:
			return "UNDA DA SEA! UNDA DA SEA!";
		case Spider:
			return "Bite and poison your enemies while fighting them!";
		case Ninja:
			return "Ninja 2.0 (idk xD)";
		case TNT:
			return "Blow up your enemies with TNT!";
		case Chicken:
			return "Bock bock backaaack! One of the best classes hehe tip";
		case DarkSethBling:
			return "The evil counterpart of the redstone King";
		case Witch:
			return "She lives in daydreams with me! (She)";
		case Sheep:
			return "Different colors of wool gives you different powers!";
		case SnowGolem:
			return "This is a SnowGolem, not a Snowman. Get it right pleb!";
		case Bunny:
			return "Easter Bunny is coming to town!";
		case ButterBro:
			return "Yo, you there Sky??";
		case IronGolem:
			return "Smack your enemies into the air while defending your village!";
		case Ghast:
			return "Burn down your enemies with your sorrows";
		case Slime:
			return "Throw sticky grenades and attack enemies!";
		case ButterGolem:
			return "Once a proud member of the Sky Army, the ButterGolem now stands as a relic of a bygone era..";
		case Bat:
			return "Dance around your opponents with SUPER high jumps!";
		case SethBling:
			return "The creator of SCB, wanna fight?!?!";
		case Melon:
			return "The Owner of the server in the game?!";
		case BabyCow:
			return "moo.. MOO!!";
		case Herobrine:
			return "Use your Diamond of Despair to play tricks on your opponents!";
		}
			
		return null;
	}

	public String getTag() {
		switch (this) {
		case Bat:
			return "" + ChatColor.DARK_GRAY + ChatColor.BOLD + ChatColor.ITALIC + "Bat";
		case Snowman:
			return "" + ChatColor.RESET + "Snow" + ChatColor.DARK_GREEN + "Man";
		case ButterGolem:
			return "" + ChatColor.YELLOW + ChatColor.BOLD + ChatColor.ITALIC + "ButterGolem";
		case Herobrine:
			return "" + ChatColor.GRAY + ChatColor.BOLD + "Herobrine";
		case Cactus:
			return "" + ChatColor.DARK_GREEN + "Cactus";
		case Chicken:
			return "" + ChatColor.YELLOW + ChatColor.BOLD + "Chicken";
		case DarkSethBling:
			return "" + ChatColor.DARK_GRAY + ChatColor.BOLD + ChatColor.ITALIC + "DarkSethBling";
		case Enderdragon:
			return "" + ChatColor.DARK_PURPLE + ChatColor.BOLD + "Ender" + ChatColor.RESET + ChatColor.BLACK
					+ ChatColor.BOLD + "Dragon";
		case Enderman:
			return "" + ChatColor.BLACK + "Enderman";
		case Ghast:
			return "" + ChatColor.RESET + "Ghast";
		case IronGolem:
			return "" + ChatColor.GRAY + ChatColor.BOLD + ChatColor.ITALIC + "IronGolem";
		case Ninja:
			return "" + ChatColor.BLACK + ChatColor.BOLD + "Ninja";
		case SethBling:
			return "" + ChatColor.RED + ChatColor.BOLD + ChatColor.ITALIC + "SethBling";
		case Sheep:
			return "" + ChatColor.RESET + ChatColor.BOLD + "Sheep";
		case Skeleton:
			return "" + ChatColor.GRAY + ChatColor.ITALIC + "Skeleton";
		case Slime:
			return "" + ChatColor.GREEN + ChatColor.BOLD + "Slime";
		case SnowGolem:
			return "" + ChatColor.RESET + ChatColor.BOLD + "SnowGolem";
		case TNT:
			return "" + ChatColor.RED + ChatColor.BOLD + "T" + ChatColor.RESET + ChatColor.BOLD + "N" + ChatColor.RESET
					+ ChatColor.RED + ChatColor.BOLD + "T";
		case Witch:
			return "" + ChatColor.DARK_PURPLE + ChatColor.BOLD + "Witch";
		case Horse:
			return "" + ChatColor.DARK_GREEN + ChatColor.ITALIC + "Horse";
		case Melon:
			return "" + ChatColor.YELLOW + "Melon";
		/*
		 * case Rabbit: return "" + ChatColor.GREEN + ChatColor.ITALIC + "Rabbit";
		 */
		case Squid:
			return "" + ChatColor.DARK_BLUE + ChatColor.ITALIC + "Squid";
		case Spider:
			return "" + ChatColor.RED + ChatColor.ITALIC + "Spider";
		case BabyCow:
			return "" + ChatColor.RED + ChatColor.ITALIC + ChatColor.BOLD + "BabyCow";
		case Bunny:
			return "" + ChatColor.YELLOW + ChatColor.ITALIC + ChatColor.BOLD + "Bunny";
		case ButterBro:
			return "" + ChatColor.YELLOW + ChatColor.BOLD + "ButterBro";
		default:
			break;

		}
		return this.toString();
	}
}