package anthony.SuperCraftBrawl.Game;

public enum GameType {
	NORMAL, FRENZY, DUEL, CTF
}
