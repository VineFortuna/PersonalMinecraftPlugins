package anthony.SuperCraftBrawl.Game;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import org.bukkit.Effect;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerFishEvent.State;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import anthony.SuperCraftBrawl.ItemHelper;
import anthony.SuperCraftBrawl.Main;
import anthony.SuperCraftBrawl.Game.classes.BaseClass;
import anthony.SuperCraftBrawl.Game.classes.ClassType;
import anthony.SuperCraftBrawl.Game.classes.Cooldown;
import anthony.SuperCraftBrawl.Game.map.Maps;
import anthony.SuperCraftBrawl.Game.projectile.ItemProjectile;
import anthony.SuperCraftBrawl.Game.projectile.ProjectileManager;
import anthony.SuperCraftBrawl.Game.projectile.ProjectileOnHit;
import anthony.SuperCraftBrawl.gui.ClassSelectorGUI;
import anthony.SuperCraftBrawl.gui.HubGUI;
import anthony.SuperCraftBrawl.gui.MysteryChestsGUI;
import anthony.SuperCraftBrawl.playerdata.PlayerData;
import net.md_5.bungee.api.ChatColor;

public class GameManager implements Listener {
	HashMap<Maps, GameInstance> gameMap;

	private final ProjectileManager projManager;
	private final Main main;
	public GameState state;
	public GameType gameType;
	public List<Maps> activeMaps = new ArrayList<>();

	public GameManager(Main main) {
		this.main = main;
		this.gameMap = new HashMap<Maps, GameInstance>();
		this.main.getServer().getPluginManager().registerEvents(this, main);
		this.projManager = new ProjectileManager(this);
	}

	public GameInstance getGameInstance(Player player) {
		for (Entry<Maps, GameInstance> entry : gameMap.entrySet()) {
			if (entry.getValue().HasPlayer(player)) {
				return entry.getValue();
			}
		}
		return null;
	}

	@EventHandler
	public void onTestEntityDamage(EntityDamageEvent event) {
		if (event.getEntity() instanceof Player) {
			Player player = (Player) event.getEntity();
			if (player.getWorld() == main.getLobbyWorld()) {
				event.setCancelled(true);
			} else {
				GameInstance instance = getGameInstance(player);

				if (instance != null) {
					if (instance.state == GameState.STARTED) {
						event.setCancelled(false);
					} else {
						event.setCancelled(true);
					}
				}
			}
		}
	}

	public ProjectileManager getProjManager() {
		return projManager;
	}

	@EventHandler
	public void OnPlayerInteract(PlayerInteractEvent event) {
		for (Entry<Maps, GameInstance> game : gameMap.entrySet()) {
			if (game.getValue().PlayerInteract(event))
				return;
		}
	}

	@EventHandler
	public void onEntityDamage(PlayerTeleportEvent event) {
		Player player = event.getPlayer();
		GameInstance instance = getGameInstance(player);

		if (event.getCause() == TeleportCause.ENDER_PEARL) {
			event.setCancelled(true);
			if (instance.isInBounds(event.getTo())) {
				player.teleport(event.getTo());
			} else {
				player.sendMessage("" + ChatColor.BOLD + "(!) " + ChatColor.RESET + "You cannot teleport there!");
			}
		}
	}

	public int getNumOfGames() {
		int num = 0;
		for (Entry<Maps, GameInstance> entry : gameMap.entrySet()) {
			if (entry.getValue().state == GameState.STARTED) {
				num++;
			}
		}
		return num;
	}

	public int getNumOfGamesFrenzy() {
		int num = 0;
		for (Entry<Maps, GameInstance> entry : gameMap.entrySet()) {
			if (entry.getValue().state == GameState.STARTED && entry.getValue().gameType == GameType.FRENZY) {
				num++;
			}
		}
		return num;
	}

	public int getNumOfGamesNormal() {
		int num = 0;
		for (Entry<Maps, GameInstance> entry : gameMap.entrySet()) {
			if (entry.getValue().state == GameState.STARTED && entry.getValue().gameType == GameType.NORMAL) {
				num++;
			}
		}
		return num;
	}

	public int getNumOfGamesDuel() {
		int num = 0;
		for (Entry<Maps, GameInstance> entry : gameMap.entrySet()) {
			if (entry.getValue().state == GameState.STARTED && entry.getValue().gameType == GameType.DUEL) {
				num++;
			}
		}
		return num;
	}

	private HashMap<Player, BukkitRunnable> borderRunnables = new HashMap<>();

	@EventHandler
	public void onPlayerMove(PlayerMoveEvent e) {
		Player player = e.getPlayer();
		GameInstance instance = getGameInstance(player);

		if (player.getWorld() == main.getLobbyWorld()) {
			if (e.getPlayer().getLocation().getY() < 50) {
				main.SendPlayerToHub(player);
			}
		}
		if (instance != null) {
			if (instance.state == GameState.STARTED) {
				if (e.getPlayer().getLocation().getY() < 50 && e.getPlayer().getGameMode() != GameMode.SPECTATOR) {
					EntityDamageEvent damageEvent = new EntityDamageEvent(e.getPlayer(), DamageCause.VOID, 1000);
					main.getServer().getPluginManager().callEvent(damageEvent);
				}
				if (!(instance.isInBounds(e.getPlayer().getLocation()))
						&& e.getPlayer().getGameMode() != GameMode.SPECTATOR) {
					BukkitRunnable runnable = borderRunnables.get(player);
					if (runnable == null) {
						runnable = new BukkitRunnable() {
							int ticks = 7;

							@Override
							public void run() {

								if (player.getGameMode() == GameMode.SPECTATOR) {
									borderRunnables.remove(player);
									this.cancel();
								}

								if (instance.state == GameState.ENDED) {
									borderRunnables.remove(player);
									this.cancel();
									player.setGameMode(GameMode.ADVENTURE);
									player.setAllowFlight(true);
								}

								if (ticks == 0) {
									//player.setGameMode(GameMode.ADVENTURE);
									player.setHealth(20.0);
									player.setAllowFlight(true);
									if (player.getGameMode() != GameMode.SPECTATOR) {
										EntityDamageEvent damageEvent = new EntityDamageEvent(e.getPlayer(),
												DamageCause.VOID, 1000);
										for (Player gamePlayer : instance.players)
											gamePlayer.playEffect(player.getLocation(), Effect.EXPLOSION_HUGE, 1);
										main.getServer().getPluginManager().callEvent(damageEvent);
										borderRunnables.remove(player);
										this.cancel();
									} else {
										borderRunnables.remove(player);
										this.cancel();
									}
								} else if (ticks <= 5 && ticks > 0 && instance.state == GameState.STARTED) {
									if (instance.isInBounds(e.getPlayer().getLocation())) {
										player.sendTitle("", "");
										borderRunnables.remove(player);
										this.cancel();
									} else {
										player.sendTitle("" + ChatColor.RED + "Warning!", "" + ChatColor.RESET
												+ "Return to Safety in " + ChatColor.YELLOW + ticks);
									}
								}
								ticks--;
							}
						};
						runnable.runTaskTimer(getMain(), 0, 20);
						borderRunnables.put(player, runnable);
					}
				}
			}
		}
	}

	public boolean chestCanOpen = false;

	@EventHandler
	public void mysteryChest(PlayerInteractEvent e) {
		ItemStack item = e.getItem();
		Player player = e.getPlayer();
		List<Material> list = new ArrayList<>(Arrays.asList(Material.CHEST));

		if (player.getWorld() == main.getLobbyWorld()) {
			if (e.getAction() == Action.RIGHT_CLICK_BLOCK && list.contains(e.getClickedBlock().getType())) {
				if (chestCanOpen == false) {
					e.setCancelled(true);
					new MysteryChestsGUI(main).inv.open(player);
				} else {
					e.setCancelled(true);
					player.sendMessage("" + ChatColor.LIGHT_PURPLE + ChatColor.BOLD + "(!) " + ChatColor.RESET
							+ "This mystery chest is already in use!");
				}
			}
		} else {
			if (e.getAction() == Action.RIGHT_CLICK_BLOCK && list.contains(e.getClickedBlock().getType())) {
				e.setCancelled(true);
			}
		}
	}

	private Cooldown boosterCooldown = new Cooldown(0), shurikenCooldown = new Cooldown(0);

	@EventHandler
	public void UseItem(PlayerInteractEvent event) {
		ItemStack item = event.getItem();
		Player player = event.getPlayer();
		GameInstance instance = getGameInstance(player);
		int amount = item.getAmount();

		if (player.isOnGround()) {
			amount = 4;
		}

		if (player.getWorld() == main.getLobbyWorld()) {
			if (item != null && item.getType() == Material.WHEAT
					&& (event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK)) {
				double boosterStrength = 1.0;
				Vector vel = player.getLocation().getDirection().setY(boosterStrength);
				player.setVelocity(vel);
			}
		}
	}

	@EventHandler
	public void votePaper(PlayerInteractEvent event) {
		ItemStack item = event.getItem();
		Player player = event.getPlayer();
		GameInstance instance = getGameInstance(player);
		PlayerData data = main.getDataManager().getPlayerData(player);

		if (instance != null) {
			if (instance.state == GameState.WAITING && instance.players.size() >= 2) {
				if (item != null && item.getType() == Material.PAPER && (event.getAction() == Action.RIGHT_CLICK_AIR
						|| event.getAction() == Action.RIGHT_CLICK_BLOCK)) {
					if (data.votes == 0) {
						instance.totalVotes++;
						data.votes = 1;
						instance.TellAll("" + ChatColor.DARK_GREEN + ChatColor.BOLD + "(!) " + ChatColor.RESET
								+ ChatColor.YELLOW + player.getName() + ChatColor.YELLOW + ChatColor.BOLD
								+ " has voted for game to start " + ChatColor.RED + "(" + ChatColor.GREEN
								+ instance.totalVotes + "/" + instance.players.size() + ChatColor.RED + ")");
					} else if (data.votes == 1) {
						player.sendMessage("" + ChatColor.DARK_GREEN + ChatColor.BOLD + "(!) " + ChatColor.RESET
								+ "You have already voted for the game to start!");
					}
				}
			}
		}
	}

	@EventHandler
	public void extraLife(PlayerInteractEvent event) {
		ItemStack item = event.getItem();
		Player player = event.getPlayer();
		GameInstance instance = getGameInstance(player);

		if (instance != null) {
			if (instance.state == GameState.STARTED) {
				if (item != null && item.getType() == Material.PRISMARINE_SHARD
						&& (event.getAction() == Action.RIGHT_CLICK_AIR
								|| event.getAction() == Action.RIGHT_CLICK_BLOCK)) {
					BaseClass baseClass = instance.classes.get(player);
					int amount = item.getAmount();
					baseClass.lives += 1;
					baseClass.score.setScore(baseClass.lives);
					baseClass.TellAll("" + ChatColor.DARK_GREEN + ChatColor.BOLD + "(!) " + ChatColor.RESET
							+ ChatColor.YELLOW + player.getName() + ChatColor.RESET + " used an extra life!");
					if (amount > 0) {
						amount--;
						if (amount == 0)
							player.getInventory().clear(player.getInventory().getHeldItemSlot());
						else
							item.setAmount(amount);
					}
				}
			}
		}
	}

	@EventHandler
	public void onFish(PlayerFishEvent e) {
		if (boosterCooldown.useAndResetCooldown()) {
			if (e.getState() == State.IN_GROUND) {
				e.getPlayer().setVelocity(
						new Vector(e.getPlayer().getVelocity().getX(), 2.5, e.getPlayer().getVelocity().getY()));
			}
		}
	}

	@EventHandler
	public void cosmeticMelon(PlayerInteractEvent e) {
		Player player = e.getPlayer();
		ItemStack item = e.getItem();
		GameInstance instance = getGameInstance(player);
		PlayerData data = main.getDataManager().getPlayerData(player);

		if (player.getWorld() == main.getLobbyWorld()) {
			if (item != null && item.getType() == Material.MELON) {
				if (player.getGameMode() != GameMode.SPECTATOR) {
					if (shurikenCooldown.useAndResetCooldown()) {
						int amount = item.getAmount();
						if (data.melon > 0) {
							data.melon--;
							player.playSound(player.getLocation(), Sound.EAT, 2, 1);
							player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 110, 2));
							if (data.melon == 0)
								player.getInventory().clear(player.getInventory().getHeldItemSlot());
							else
								item.setAmount(data.melon);
						}
						e.setCancelled(true);
					}
				}
			}
		}
	}

	@EventHandler
	public void bazooka(PlayerInteractEvent e) {
		Player player = e.getPlayer();
		ItemStack item = e.getItem();
		GameInstance instance = getGameInstance(player);

		if (instance != null && instance.state == GameState.STARTED) {
			if (item.getType() == Material.DIAMOND_HOE) {
				if (player.getGameMode() != GameMode.SPECTATOR) {
					if (shurikenCooldown.useAndResetCooldown()) {
						int amount = item.getAmount();
						if (amount > 0) {
							amount--;
							if (amount == 0)
								player.getInventory().clear(player.getInventory().getHeldItemSlot());
							else
								item.setAmount(amount);
							ItemProjectile proj = new ItemProjectile(instance, player, new ProjectileOnHit() {
								@Override
								public void onHit(Player hit) {
									player.playSound(hit.getLocation(), Sound.SUCCESSFUL_HIT, 1, 1);
									hit.damage(6.5, player);
									for (Player gamePlayer : instance.players) {
										gamePlayer.playSound(hit.getLocation(), Sound.EXPLODE, 2, 1);
										gamePlayer.playEffect(hit.getLocation(), Effect.EXPLOSION_HUGE, 1);
									}

								}

							}, new ItemStack(Material.TNT));
							instance.getManager().getProjManager().shootProjectile(proj, player.getEyeLocation(),
									player.getLocation().getDirection().multiply(2.0D));
						}
						e.setCancelled(true);
					}
				}
			}
		}
	}

	@EventHandler
	public void milk(PlayerInteractEvent e) {
		Player player = e.getPlayer();
		ItemStack item = e.getItem();
		GameInstance instance = getGameInstance(player);

		if (instance != null && instance.state == GameState.STARTED) {
			if (item.getType() == Material.MILK_BUCKET) {
				if (player.getGameMode() != GameMode.SPECTATOR) {
					if (shurikenCooldown.useAndResetCooldown()) {
						player.removePotionEffect(PotionEffectType.POISON);
						player.sendMessage("" + ChatColor.RESET + ChatColor.DARK_GREEN + ChatColor.BOLD + "(!) "
								+ ChatColor.RESET + "You feel refreshed!");
						int amount = item.getAmount();
						if (amount > 0) {
							amount--;
							if (amount == 0)
								player.getInventory().clear(player.getInventory().getHeldItemSlot());
							else
								item.setAmount(amount);
						}
						e.setCancelled(true);
					}
				}
			}
		}
	}

	@EventHandler
	public void classSelector(PlayerInteractEvent e) {
		Player player = e.getPlayer();

		ItemStack compass = new ItemStack(Material.COMPASS);
		ItemMeta meta = compass.getItemMeta();
		GameInstance instance = getGameInstance(player);

		if (e.getItem() != null && e.getItem().getType() == Material.COMPASS) {
			if (instance != null)
				if (instance.state == GameState.WAITING)
					new ClassSelectorGUI(main).inv.open(e.getPlayer());

			if (player.getWorld() == main.getLobbyWorld())
				new HubGUI(main).inv.open(e.getPlayer());
		}
	}

	@EventHandler
	public void activeGames(PlayerInteractEvent e) {
		/*
		 * Player player = e.getPlayer();
		 * 
		 * ItemStack eye = new ItemStack(Material.EYE_OF_ENDER); ItemMeta meta =
		 * eye.getItemMeta(); GameInstance instance = getGameInstance(player);
		 * 
		 * if (e.getItem() != null && e.getItem().getType() == Material.EYE_OF_ENDER) {
		 * if (player.getWorld() == main.getLobbyWorld()) { e.setCancelled(true); new
		 * ActiveGamesGUI(main, instance).inv.open(e.getPlayer()); } }
		 */
	}

	@EventHandler
	public void OnPickupItem(PlayerPickupItemEvent event) {
		Item item = event.getItem();
		if (projManager.isProjectile(item)) {
			event.setCancelled(true);
		}
	}

	@EventHandler
	public void onPortal(PlayerPortalEvent event) {
		event.setCancelled(true);
	}

	@EventHandler(priority = EventPriority.HIGHEST)
	public void OnEntityDamage(EntityDamageEvent event) {
		if (event.getEntity() instanceof Player) {
			Player player = (Player) event.getEntity();
			GameInstance instance = GetInstanceOfPlayer(player);
			if (instance != null) {
				if (event instanceof EntityDamageByEntityEvent) {
					EntityDamageByEntityEvent damageEvent = (EntityDamageByEntityEvent) event;
					if (damageEvent.getDamager() instanceof Player) {
						Player damager = (Player) damageEvent.getDamager();
						BaseClass baseClass = instance.classes.get(damager);
						baseClass.DoDamage(damageEvent);
					}
				}
				if (!event.isCancelled() && event.getFinalDamage() >= player.getHealth() - 0.2) {
					event.setCancelled(true);
					instance.PlayerDeath(player);
					return;
				} else
					instance.classes.get(player).TakeDamage(event);
			}
		}
	}

	public Main getMain() {
		return main;
	}

	public void playerSelectClass(Player player, ClassType type) {
		GameInstance instance = this.GetInstanceOfPlayer(player);
		if (instance != null)
			instance.setClass(player, type);
	}

	public GameInstance getWaitingMap() {
		for (Entry<Maps, GameInstance> entry : this.gameMap.entrySet()) {
			if (entry.getValue().state == GameState.WAITING && entry.getValue().players.size() > 0)
				if (entry.getValue().gameType == GameType.NORMAL && entry.getValue().players.size() == 5)
					return null;
				else if (entry.getValue().gameType == GameType.NORMAL && entry.getValue().players.size() < 5)
					return entry.getValue();
				else if (entry.getValue().gameType == GameType.DUEL && entry.getValue().players.size() == 2)
					return null;
				else if (entry.getValue().gameType == GameType.DUEL && entry.getValue().players.size() < 2)
					return entry.getValue();
				else if (entry.getValue().gameType == GameType.FRENZY)
					return entry.getValue();
		}
		return null;
	}

	public void JoinMap(Player player, Maps map) {
		GameReason result = main.getGameManager().AddPlayerToMap(player, map);
		GameInstance instance = this.GetInstanceOfPlayer(player);
		switch (result) {
		case SUCCESS:
			player.sendMessage("" + ChatColor.DARK_GREEN + ChatColor.BOLD + "(!) " + ChatColor.RESET
					+ "You have joined " + ChatColor.RESET + ChatColor.WHITE + ChatColor.BOLD + map.toString());
			player.playSound(player.getLocation(), Sound.SUCCESSFUL_HIT, 1, 1);

			if (instance.gameType == GameType.FRENZY) {
				player.sendMessage("" + ChatColor.DARK_GREEN + ChatColor.BOLD + "(!) " + ChatColor.RESET
						+ "You have joined a Frenzy game, your class will be randomly selected each life");
			}

			player.setGameMode(GameMode.ADVENTURE);
			player.setAllowFlight(true);

			player.getInventory().clear();

			if (instance.gameType != GameType.FRENZY) {
				ItemStack classItem = ItemHelper.setDetails(new ItemStack(Material.COMPASS),
						"" + ChatColor.GREEN + ChatColor.BOLD + "Class Selector",
						ChatColor.GRAY + "Click to choose a class!");
				player.getInventory().setItem(0, classItem);
			}

			ItemStack stats = new ItemStack(Material.SKULL_ITEM, 1, (byte) 3);
			SkullMeta statsMeta = (SkullMeta) stats.getItemMeta();
			statsMeta.setOwner(player.getName());
			stats.setItemMeta(statsMeta);

			player.getInventory().setItem(4,
					ItemHelper.setDetails(stats, "" + ChatColor.RESET + ChatColor.BOLD + "Profile"));

			ItemStack leaveItem = ItemHelper.setDetails(new ItemStack(Material.BARRIER),
					"" + ChatColor.RED + ChatColor.BOLD + "Leave Game", ChatColor.GRAY + "Click to leave your game");
			player.getInventory().setItem(8, leaveItem);

			break;
		case ALREADY_IN:

			player.sendMessage(
					"" + ChatColor.WHITE + ChatColor.BOLD + "(!) " + ChatColor.RESET + "You are already in a map!");

			break;

		case IN_ANOTHER:
			player.sendMessage("" + ChatColor.BOLD + "(!) " + ChatColor.RESET + "You are already in a game!");
			break;

		case ALREADYPLAYING:
			player.sendMessage(
					"" + ChatColor.WHITE + ChatColor.BOLD + "(!) " + ChatColor.RESET + "This game is already playing!");
			break;
		}
	}

	public void SpectatorJoinMap(Player player, Maps map) {
		GameReason result = main.getGameManager().AddSpectatorToMap(player, map);
		GameInstance instance = getGameInstance(player);

		switch (result) {
		case SPECTATOR:
			player.sendMessage("" + ChatColor.BOLD + "(!) " + ChatColor.RESET + "You are now spectating " + ""
					+ ChatColor.GREEN + map.toString() + "." + ChatColor.RESET + " Use " + ChatColor.GREEN + "/hub "
					+ ChatColor.RESET + "to leave");
			player.setGameMode(GameMode.SPECTATOR);
			// instance.GameScoreboard();
			break;

		case ALREADY_IN:
			player.sendMessage("" + ChatColor.WHITE + ChatColor.BOLD + "(!) " + ChatColor.RESET
					+ "You have to leave your game to Spectate");
			break;

		case FAIL:
			player.sendMessage("" + ChatColor.BOLD + "(!) " + ChatColor.RESET + "This game is not playing!");
			break;
		}
	}

	public GameReason AddSpectatorToMap(Player player, Maps map) {
		GameInstance instance = null;

		if (GetInstanceOfPlayer(player) != null) {
			player.sendMessage("" + ChatColor.WHITE + ChatColor.BOLD + "(!) " + ChatColor.RESET
					+ "You have to leave your game to Spectate");
			return GameReason.IN_ANOTHER;
		}

		if (gameMap.containsKey(map))
			instance = gameMap.get(map);
		else {
			instance = new GameInstance(this, map);
			gameMap.put(map, instance);
		}

		return instance.AddSpectator(player);
	}

	public GameReason AddPlayerToMap(Player player, Maps map) {
		GameInstance instance = null;

		if (GetInstanceOfPlayer(player) != null) {
			return GameReason.IN_ANOTHER;
		}
		if (gameMap.containsKey(map))
			instance = gameMap.get(map);
		else {
			instance = new GameInstance(this, map);
			gameMap.put(map, instance);
		}

		GameReason reason = instance.AddPlayer(player);
		main.getNPCManager().updateNpc(map);

		return reason;
	}

	@EventHandler
	public void onWeatherChange(WeatherChangeEvent event) {
		event.setCancelled(true);
	}

	@EventHandler
	public void PlayerInteractEvent(PlayerInteractEvent event) {
		if ((event.getAction() == Action.PHYSICAL) && (event.getClickedBlock().getType() == Material.SOIL)) {
			event.setCancelled(true);
		}
	}

	public GameInstance GetInstanceOfPlayer(Player player) {
		for (Entry<Maps, GameInstance> games : gameMap.entrySet())
			if (games.getValue().HasPlayer(player))
				return games.getValue();
		return null;
	}

	public GameInstance getInstanceOfMap(Maps map) {
		return gameMap.get(map);
	}

	public void RemovePlayerFromMap(Player player, Maps map, Player player2) {
		if (gameMap.containsKey(map)) {
			gameMap.get(map).RemovePlayer(player);
			main.getNPCManager().updateNpc(map);
		}
	}

	public boolean RemovePlayerFromAll(Player player) {
		PlayerData data = main.getDataManager().getPlayerData(player);
		GameInstance instance = main.getGameManager().GetInstanceOfPlayer(player);

		if (data.votes == 1) {
			if (instance != null) {
				instance.totalVotes--;
				data.votes = 0;
			}
		}

		for (Entry<Maps, GameInstance> games : gameMap.entrySet())
			if (games.getValue().RemovePlayer(player)) {
				main.getNPCManager().updateNpc(games.getKey());
				return true;
			}
		return false;
	}

	public void RemoveMap(Maps maps) {
		gameMap.remove(maps);
		main.getNPCManager().updateNpc(maps);
	}
}
