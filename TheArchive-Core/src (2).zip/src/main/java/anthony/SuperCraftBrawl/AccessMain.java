package anthony.SuperCraftBrawl;

public class AccessMain {

	private final Main main;
	
	public AccessMain(Main main) {
		this.main = main;
	}
	
	public Main getMain() {
		return main;
	}
	
}
