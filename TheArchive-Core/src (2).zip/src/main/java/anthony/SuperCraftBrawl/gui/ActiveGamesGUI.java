package anthony.SuperCraftBrawl.gui;

import org.bukkit.entity.Player;

import anthony.SuperCraftBrawl.Main;
import anthony.SuperCraftBrawl.Game.GameInstance;
import fr.minuskube.inv.SmartInventory;
import fr.minuskube.inv.content.InventoryContents;
import fr.minuskube.inv.content.InventoryProvider;
import net.md_5.bungee.api.ChatColor;

public class ActiveGamesGUI implements InventoryProvider {

	public Main main;
	public SmartInventory inv;
	private GameInstance instance;

	public ActiveGamesGUI(Main main, GameInstance instance) {
		inv = SmartInventory.builder().id("myInventory").provider(this).size(3, 9)
				.title("" + ChatColor.YELLOW + ChatColor.BOLD + "All Maps").build();
		this.main = main;
		this.instance = instance;
	}

	@Override
	public void init(Player player, InventoryContents contents) {
		
	}

	@Override
	public void update(Player player, InventoryContents contents) {

	}
}
