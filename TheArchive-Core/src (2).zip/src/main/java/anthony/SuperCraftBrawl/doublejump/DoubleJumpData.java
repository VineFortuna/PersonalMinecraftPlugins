package anthony.SuperCraftBrawl.doublejump;

import org.bukkit.util.Vector;

public class DoubleJumpData {

	boolean canDoubleJump = true;
	Vector lastVelocity = new Vector();
}
