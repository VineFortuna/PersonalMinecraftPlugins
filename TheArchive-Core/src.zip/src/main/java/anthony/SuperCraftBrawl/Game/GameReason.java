package anthony.SuperCraftBrawl.Game;

public enum GameReason {
	SUCCESS, ALREADY_IN, IN_ANOTHER, ALREADYPLAYING, FULL, SPECTATOR, FAIL, FORCESTARTGAME, NOT_ENOUGH
}
