package anthony.SuperCraftBrawl.Game;

import java.util.HashMap;
import java.util.Map.Entry;

import org.bukkit.Effect;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import anthony.SuperCraftBrawl.ClassSelectorGUI;
import anthony.SuperCraftBrawl.HubGUI;
import anthony.SuperCraftBrawl.ItemHelper;
import anthony.SuperCraftBrawl.Main;
import anthony.SuperCraftBrawl.Game.classes.BaseClass;
import anthony.SuperCraftBrawl.Game.classes.ClassType;
import anthony.SuperCraftBrawl.Game.classes.Cooldown;
import anthony.SuperCraftBrawl.Game.map.Maps;
import anthony.SuperCraftBrawl.Game.projectile.ItemProjectile;
import anthony.SuperCraftBrawl.Game.projectile.ProjectileManager;
import anthony.SuperCraftBrawl.Game.projectile.ProjectileOnHit;
import anthony.SuperCraftBrawl.playerdata.PlayerData;
import net.md_5.bungee.api.ChatColor;

public class GameManager implements Listener {
	HashMap<Maps, GameInstance> gameMap;

	private final ProjectileManager projManager;
	private final Main main;
	public GameState state;
	public GameType gameType;

	public GameManager(Main main) {
		this.main = main;
		this.gameMap = new HashMap<Maps, GameInstance>();
		this.main.getServer().getPluginManager().registerEvents(this, main);
		this.projManager = new ProjectileManager(this);
	}

	public GameInstance getGameInstance(Player player) {
		for (Entry<Maps, GameInstance> entry : gameMap.entrySet()) {
			if (entry.getValue().HasPlayer(player)) {
				return entry.getValue();
			}
		}
		return null;
	}

	@EventHandler
	public void onTestEntityDamage(EntityDamageEvent event) {
		if (event.getEntity() instanceof Player) {
			Player player = (Player) event.getEntity();
			if (player.getWorld() == main.getLobbyWorld()) {
				event.setCancelled(true);
			} else {
				GameInstance instance = getGameInstance(player);

				if (instance != null) {
					if (instance.state == GameState.STARTED) {
						event.setCancelled(false);
					} else {
						event.setCancelled(true);
					}
				}
			}
		}
	}

	/*
	 * public boolean onCommand(CommandSender sender, Command cmd, String label,
	 * String[] args) { Player player = (Player) sender; GameInstance instance =
	 * getGameInstance(player);
	 * 
	 * if (cmd.getName().equalsIgnoreCase("startgame")) { if
	 * (player.hasPermission("scb.startGame")) { if (instance.state ==
	 * GameState.STARTING) { instance.TellAll( "" + ChatColor.BOLD + "(!) " +
	 * ChatColor.RESET + "Game has been force started by an Admin");
	 * instance.ticksTilStart = 1; } else { player.sendMessage("" + ChatColor.BOLD +
	 * "(!) " + ChatColor.RESET + "Not enough players to start!"); } } else {
	 * player.sendMessage("" + ChatColor.BOLD + "(!) " + ChatColor.RESET +
	 * "You do not have permission to use this command!"); } }
	 * 
	 * return false; }
	 */

	public ProjectileManager getProjManager() {
		return projManager;
	}

	@EventHandler
	public void OnPlayerInteract(PlayerInteractEvent event) {
		for (Entry<Maps, GameInstance> game : gameMap.entrySet()) {
			if (game.getValue().PlayerInteract(event))
				return;
		}
	}

	@EventHandler
	public void onPlayerMove(PlayerMoveEvent e) {
		Player player = e.getPlayer();
		GameInstance instance = getGameInstance(player);

		if (player.getWorld() == main.getLobbyWorld()) {
			if (e.getPlayer().getLocation().getY() < 50) {
				main.SendPlayerToHub(player);
			}
		}
		if (instance != null) {
			if (instance.state == GameState.STARTED) {
				if (e.getPlayer().getLocation().getY() < 50 && e.getPlayer().getGameMode() != GameMode.SPECTATOR) {
					EntityDamageEvent damageEvent = new EntityDamageEvent(e.getPlayer(), DamageCause.VOID, 1000);

					main.getServer().getPluginManager().callEvent(damageEvent);
				}
			}
		}
	}

	private Cooldown boosterCooldown = new Cooldown(0), shurikenCooldown = new Cooldown(0);

	@EventHandler
	public void UseItem(PlayerInteractEvent event) {
		ItemStack item = event.getItem();
		Player player = event.getPlayer();
		GameInstance instance = getGameInstance(player);

		if (player.getWorld() == main.getLobbyWorld()) {
			if (item != null && item.getType() == Material.WHEAT
					&& (event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK)) {
				if (boosterCooldown.useAndResetCooldown()) {
					double boosterStrength = 2.5;
					Vector vel = player.getLocation().getDirection().multiply(boosterStrength);
					player.setVelocity(vel);
				}
			}
		}
	}
	
	@EventHandler
	public void cosmeticMelon(PlayerInteractEvent e) {
		Player player = e.getPlayer();
		ItemStack item = e.getItem();
		GameInstance instance = getGameInstance(player);
		PlayerData data = main.getDataManager().getPlayerData(player);

		if (player.getWorld() == main.getLobbyWorld()) {
			if (item.getType() == Material.MELON) {
				if (player.getGameMode() != GameMode.SPECTATOR) {
					if (shurikenCooldown.useAndResetCooldown()) {
						int amount = item.getAmount();
						if (data.melon > 0) {
							data.melon--;
							player.playSound(player.getLocation(), Sound.EAT,  2, 1);
							player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 110, 2));
							if (data.melon == 0)
								player.getInventory().clear(player.getInventory().getHeldItemSlot());
							else
								item.setAmount(data.melon);
							ItemProjectile proj = new ItemProjectile(instance, player, new ProjectileOnHit() {
								@Override
								public void onHit(Player hit) {

								}

							}, new ItemStack(Material.MELON));
							instance.getManager().getProjManager().shootProjectile(proj, player.getEyeLocation(),
									player.getLocation().getDirection().multiply(2.0D));
						}
						e.setCancelled(true);
					}
				}
			}
		}
	}

	@EventHandler
	public void bazooka(PlayerInteractEvent e) {
		Player player = e.getPlayer();
		ItemStack item = e.getItem();
		GameInstance instance = getGameInstance(player);

		if (instance.state == GameState.STARTED) {
			if (item.getType() == Material.DIAMOND_HOE) {
				if (player.getGameMode() != GameMode.SPECTATOR) {
					if (shurikenCooldown.useAndResetCooldown()) {
						int amount = item.getAmount();
						if (amount > 0) {
							amount--;
							if (amount == 0)
								player.getInventory().clear(player.getInventory().getHeldItemSlot());
							else
								item.setAmount(amount);
							ItemProjectile proj = new ItemProjectile(instance, player, new ProjectileOnHit() {
								@Override
								public void onHit(Player hit) {
									player.playSound(hit.getLocation(), Sound.SUCCESSFUL_HIT, 1, 1);
									hit.damage(6.5, player);
									for (Player gamePlayer : instance.players) {
										gamePlayer.playSound(hit.getLocation(), Sound.EXPLODE, 2, 1);
										gamePlayer.playEffect(hit.getLocation(), Effect.EXPLOSION_HUGE, 1);
									}

								}

							}, new ItemStack(Material.TNT));
							instance.getManager().getProjManager().shootProjectile(proj, player.getEyeLocation(),
									player.getLocation().getDirection().multiply(2.0D));
						}
						e.setCancelled(true);
					}
				}
			}
		}
	}

	@EventHandler
	public void classSelector(PlayerInteractEvent e) {
		Player player = e.getPlayer();

		ItemStack compass = new ItemStack(Material.COMPASS);
		ItemMeta meta = compass.getItemMeta();
		GameInstance instance = getGameInstance(player);

		if (e.getItem() != null && e.getItem().getType() == Material.COMPASS) {
			if (instance != null) {
				if (instance.state == GameState.WAITING) {
					new ClassSelectorGUI(main).inv.open(e.getPlayer());
				} else {

				}
			}

			if (player.getWorld() == main.getLobbyWorld()) {
				new HubGUI(main).inv.open(e.getPlayer());
			}
		}
		/*
		 * else if (e.getItem() != null && e.getItem().getType() == Material.BARRIER) {
		 * new QuitGUI(main).invQuit.open(e.getPlayer()); }
		 */
	}

	@EventHandler
	public void OnPickupItem(PlayerPickupItemEvent event) {
		Item item = event.getItem();
		if (projManager.isProjectile(item)) {
			event.setCancelled(true);
		}
	}

	@EventHandler
	public void OnEntityDamage(EntityDamageEvent event) {
		if (event.getEntity() instanceof Player) {
			Player player = (Player) event.getEntity();
			GameInstance instance = GetInstanceOfPlayer(player);
			if (instance != null) {
				if (event instanceof EntityDamageByEntityEvent) {
					EntityDamageByEntityEvent damageEvent = (EntityDamageByEntityEvent) event;
					if (damageEvent.getDamager() instanceof Player) {
						Player damager = (Player) damageEvent.getDamager();
						BaseClass baseClass = instance.classes.get(damager);
						baseClass.DoDamage(damageEvent);
					}
				}
				if (!event.isCancelled() && event.getFinalDamage() >= player.getHealth() - 0.2) {
					event.setCancelled(true);
					instance.PlayerDeath(player);
					return;
				} else
					instance.classes.get(player).TakeDamage(event);
			}
		}
	}

	public Main getMain() {
		return main;
	}

	public void playerSelectClass(Player player, ClassType type) {
		GameInstance instance = this.GetInstanceOfPlayer(player);
		if (instance != null)
			instance.setClass(player, type);
	}

	public void JoinMap(Player player, Maps map) {
		GameReason result = main.getGameManager().AddPlayerToMap(player, map);
		switch (result) {
		case SUCCESS:
			player.sendMessage("" + ChatColor.DARK_GREEN + ChatColor.BOLD + "(!) " + ChatColor.RESET + ChatColor.GREEN
					+ "Successfully joined map: " + ChatColor.RESET + ChatColor.WHITE + ChatColor.BOLD
					+ map.toString());
			player.playSound(player.getLocation(), Sound.SUCCESSFUL_HIT, 1, 1);

			player.setGameMode(GameMode.ADVENTURE);
			player.setAllowFlight(true);

			player.getInventory().clear();

			ItemStack classItem = ItemHelper.setDetails(new ItemStack(Material.COMPASS),
					"" + ChatColor.GREEN + ChatColor.BOLD + "Class Selector",
					ChatColor.GRAY + "Click to choose a class!");
			player.getInventory().setItem(0, classItem);

			ItemStack stats = new ItemStack(Material.SKULL_ITEM, 1, (byte) 3);
			SkullMeta statsMeta = (SkullMeta) stats.getItemMeta();
			statsMeta.setOwner(player.getName());
			stats.setItemMeta(statsMeta);

			player.getInventory().setItem(4,
					ItemHelper.setDetails(stats, "" + ChatColor.RESET + ChatColor.BOLD + "Profile"));

			ItemStack leaveItem = ItemHelper.setDetails(new ItemStack(Material.BARRIER),
					"" + ChatColor.RED + ChatColor.BOLD + "Leave Game", ChatColor.GRAY + "Click to leave your game");
			player.getInventory().setItem(8, leaveItem);

			break;
		case ALREADY_IN:

			player.sendMessage(
					"" + ChatColor.WHITE + ChatColor.BOLD + "(!) " + ChatColor.RESET + "You are already in a map!");

			break;

		case IN_ANOTHER:
			player.sendMessage("" + ChatColor.BOLD + "(!) " + ChatColor.RESET + "You are already in a game!");
			break;

		case ALREADYPLAYING:
			player.sendMessage(
					"" + ChatColor.WHITE + ChatColor.BOLD + "(!) " + ChatColor.RESET + "This game is already playing!");
			break;
		}
	}

	public void SpectatorJoinMap(Player player, Maps map) {
		GameReason result = main.getGameManager().AddSpectatorToMap(player, map);
		GameInstance instance = getGameInstance(player);

		switch (result) {
		case SPECTATOR:
			player.sendMessage("" + ChatColor.BOLD + "(!) " + ChatColor.RESET + "You are now spectating " + ""
					+ ChatColor.GREEN + map.toString() + "." + ChatColor.RESET + " Use " + ChatColor.GREEN + "/hub "
					+ ChatColor.RESET + "to leave");
			player.setGameMode(GameMode.SPECTATOR);
			// instance.setGameScore(player);
			break;

		case ALREADY_IN:
			player.sendMessage("" + ChatColor.WHITE + ChatColor.BOLD + "(!) " + ChatColor.RESET
					+ "You have to leave your game to Spectate");
			break;

		case FAIL:
			player.sendMessage("" + ChatColor.BOLD + "(!) " + ChatColor.RESET + "This game is not playing!");
			break;
		}
	}

	public GameReason AddSpectatorToMap(Player player, Maps map) {
		GameInstance instance = null;

		if (GetInstanceOfPlayer(player) != null) {
			player.sendMessage("" + ChatColor.WHITE + ChatColor.BOLD + "(!) " + ChatColor.RESET
					+ "You have to leave your game to Spectate");
			return GameReason.IN_ANOTHER;
		}

		if (gameMap.containsKey(map))
			instance = gameMap.get(map);
		else {
			instance = new GameInstance(this, map);
			gameMap.put(map, instance);
		}

		return instance.AddSpectator(player);
	}

	public GameReason AddPlayerToMap(Player player, Maps map) {
		GameInstance instance = null;
		if (GetInstanceOfPlayer(player) != null) {
			return GameReason.IN_ANOTHER;
		}
		if (gameMap.containsKey(map))
			instance = gameMap.get(map);
		else {
			instance = new GameInstance(this, map);
			gameMap.put(map, instance);
		}

		GameReason reason = instance.AddPlayer(player);

		/*
		 * player.getInventory().clear();
		 * 
		 * ItemStack classItem = ItemHelper.setDetails(new ItemStack(Material.COMPASS),
		 * "" + ChatColor.GREEN + ChatColor.BOLD + "Class Selector", ChatColor.GRAY +
		 * "Click to choose a class!"); player.getInventory().setItem(0, classItem);
		 * 
		 * ItemStack statsItem = ItemHelper.setDetails(new
		 * ItemStack(Material.SKULL_ITEM), "" + ChatColor.BOLD + "Stats", ChatColor.GRAY
		 * + "Click to view your stats!"); player.getInventory().setItem(4, statsItem);
		 * 
		 * ItemStack leaveItem = ItemHelper.setDetails(new ItemStack(Material.BARRIER),
		 * "" + ChatColor.RED + ChatColor.BOLD + "Leave Game", ChatColor.GRAY +
		 * "Click to leave your game"); player.getInventory().setItem(8, leaveItem);
		 */

		main.getNPCManager().updateNpc(map);
		return reason;
	}

	@EventHandler
	public void onWeatherChange(WeatherChangeEvent event) {
		event.setCancelled(true);
	}

	@EventHandler
	public void PlayerInteractEvent(PlayerInteractEvent event) {
		if ((event.getAction() == Action.PHYSICAL) && (event.getClickedBlock().getType() == Material.SOIL)) {
			event.setCancelled(true);
		}
	}

	public GameInstance GetInstanceOfPlayer(Player player) {
		for (Entry<Maps, GameInstance> games : gameMap.entrySet())
			if (games.getValue().HasPlayer(player))
				return games.getValue();
		return null;
	}

	public GameInstance getInstanceOfMap(Maps map) {
		return gameMap.get(map);
	}

	public void RemovePlayerFromMap(Player player, Maps map, Player player2) {
		if (gameMap.containsKey(map)) {
			gameMap.get(map).RemovePlayer(player);
			main.getNPCManager().updateNpc(map);
		}
	}

	public boolean RemovePlayerFromAll(Player player) {
		for (Entry<Maps, GameInstance> games : gameMap.entrySet())
			if (games.getValue().RemovePlayer(player)) {
				main.getNPCManager().updateNpc(games.getKey());
				return true;
			}
		return false;
	}

	public void RemoveMap(Maps maps) {
		gameMap.remove(maps);
		main.getNPCManager().updateNpc(maps);
	}
}
