package anthony.SuperCraftBrawl.Game.projectile;

import org.bukkit.entity.Player;

public interface ProjectileOnHit {

	public void onHit(Player hit);
}
