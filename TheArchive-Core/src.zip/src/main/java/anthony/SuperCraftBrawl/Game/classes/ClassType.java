package anthony.SuperCraftBrawl.Game.classes;

import org.bukkit.entity.Player;

import anthony.SuperCraftBrawl.Game.GameInstance;
import anthony.SuperCraftBrawl.Game.classes.all.BabyCowClass;
import anthony.SuperCraftBrawl.Game.classes.all.BatClass;
import anthony.SuperCraftBrawl.Game.classes.all.BunnyClass;
import anthony.SuperCraftBrawl.Game.classes.all.ButterGolemClass;
import anthony.SuperCraftBrawl.Game.classes.all.Cactus;
import anthony.SuperCraftBrawl.Game.classes.all.ChickenClass;
import anthony.SuperCraftBrawl.Game.classes.all.DarkSethBling;
import anthony.SuperCraftBrawl.Game.classes.all.EnderdragonClass;
import anthony.SuperCraftBrawl.Game.classes.all.EndermanClass;
import anthony.SuperCraftBrawl.Game.classes.all.GhastClass;
import anthony.SuperCraftBrawl.Game.classes.all.HerobrineClass;
import anthony.SuperCraftBrawl.Game.classes.all.HorseClass;
import anthony.SuperCraftBrawl.Game.classes.all.IrongolemClass;
//import anthony.SuperCraftBrawl.Game.classes.all.JebClass;
import anthony.SuperCraftBrawl.Game.classes.all.NinjaClass;
import anthony.SuperCraftBrawl.Game.classes.all.SatermelonClass;
import anthony.SuperCraftBrawl.Game.classes.all.SethBlingClass;
import anthony.SuperCraftBrawl.Game.classes.all.SheepClass;
import anthony.SuperCraftBrawl.Game.classes.all.SkeletonClass;
import anthony.SuperCraftBrawl.Game.classes.all.SlimeClass;
import anthony.SuperCraftBrawl.Game.classes.all.SnowGolemClass;
import anthony.SuperCraftBrawl.Game.classes.all.SpiderClass;
import anthony.SuperCraftBrawl.Game.classes.all.SquidClass;
import anthony.SuperCraftBrawl.Game.classes.all.TNTClass;
import anthony.SuperCraftBrawl.Game.classes.all.WitchClass;
import net.md_5.bungee.api.ChatColor;

public enum ClassType {

	Cactus, TNT, Enderdragon, Skeleton, Ninja, IronGolem, Enderman, Ghast, Chicken, Slime, ButterGolem, DarkSethBling,
	Witch, SnowGolem, Bat, SethBling, Sheep, Horse, Melon, /* Rabbit, */ Squid, Spider, BabyCow, Herobrine, Bunny;

	public BaseClass GetClassInstance(GameInstance instance, Player player) {
		switch (this) {
		case Cactus:
			return new Cactus(instance, player);
		case Enderdragon:
			return new EnderdragonClass(instance, player);
		case Skeleton:
			return new SkeletonClass(instance, player);
		case TNT:
			return new TNTClass(instance, player);
		case Ninja:
			return new NinjaClass(instance, player);
		case IronGolem:
			return new IrongolemClass(instance, player);
		case Enderman:
			return new EndermanClass(instance, player);
		case Ghast:
			return new GhastClass(instance, player);
		case Herobrine:
			return new HerobrineClass(instance, player);
		case Chicken:
			return new ChickenClass(instance, player);
		case Slime:
			return new SlimeClass(instance, player);
		case ButterGolem:
			return new ButterGolemClass(instance, player);
		case DarkSethBling:
			return new DarkSethBling(instance, player);
		case Witch:
			return new WitchClass(instance, player);
		case SnowGolem:
			return new SnowGolemClass(instance, player);
		case Bat:
			return new BatClass(instance, player);
		case SethBling:
			return new SethBlingClass(instance, player);
		case Sheep:
			return new SheepClass(instance, player);
		case Horse:
			return new HorseClass(instance, player);
		case Melon:
			return new SatermelonClass(instance, player);
		/*
		 * case Rabbit: return new RabbitClass(instance, player);
		 */
		case Squid:
			return new SquidClass(instance, player);
		case Spider:
			return new SpiderClass(instance, player);
		case BabyCow:
			return new BabyCowClass(instance, player);
		case Bunny:
			return new BunnyClass(instance, player);
		}
		return null;
	}

	public String getTag() {
		switch (this) {
		case Bat:
			return "" + ChatColor.DARK_GRAY + ChatColor.BOLD + ChatColor.ITALIC + "Bat";
		case ButterGolem:
			return "" + ChatColor.YELLOW + ChatColor.BOLD + ChatColor.ITALIC + "ButterGolem";
		case Herobrine:
			return "" + ChatColor.GRAY + ChatColor.BOLD + "Herobrine";
		case Cactus:
			return "" + ChatColor.DARK_GREEN + "Cactus";
		case Chicken:
			return "" + ChatColor.YELLOW + ChatColor.BOLD + "Chicken";
		case DarkSethBling:
			return "" + ChatColor.DARK_GRAY + ChatColor.BOLD + ChatColor.ITALIC + "DarkSethBling";
		case Enderdragon:
			return "" + ChatColor.DARK_PURPLE + ChatColor.BOLD + "Ender" + ChatColor.RESET + ChatColor.BLACK
					+ ChatColor.BOLD + "Dragon";
		case Enderman:
			return "" + ChatColor.BLACK + "Enderman";
		case Ghast:
			return "" + ChatColor.RESET + "Ghast";
		case IronGolem:
			return "" + ChatColor.GRAY + ChatColor.BOLD + ChatColor.ITALIC + "IronGolem";
		case Ninja:
			return "" + ChatColor.BLACK + ChatColor.BOLD + "Ninja";
		case SethBling:
			return "" + ChatColor.RED + ChatColor.BOLD + ChatColor.ITALIC + "SethBling";
		case Sheep:
			return "" + ChatColor.RESET + ChatColor.BOLD + "Sheep";
		case Skeleton:
			return "" + ChatColor.GRAY + ChatColor.ITALIC + "Skeleton";
		case Slime:
			return "" + ChatColor.GREEN + ChatColor.BOLD + "Slime";
		case SnowGolem:
			return "" + ChatColor.RESET + ChatColor.BOLD + "SnowGolem";
		case TNT:
			return "" + ChatColor.RED + ChatColor.BOLD + "T" + ChatColor.RESET + ChatColor.BOLD + "N" + ChatColor.RESET
					+ ChatColor.RED + ChatColor.BOLD + "T";
		case Witch:
			return "" + ChatColor.DARK_PURPLE + ChatColor.BOLD + "Witch";
		case Horse:
			return "" + ChatColor.DARK_GREEN + ChatColor.ITALIC + "Horse";
		case Melon:
			return "" + ChatColor.YELLOW + "Melon";
		/*
		 * case Rabbit: return "" + ChatColor.GREEN + ChatColor.ITALIC + "Rabbit";
		 */
		case Squid:
			return "" + ChatColor.DARK_BLUE + ChatColor.ITALIC + "Squid";
		case Spider:
			return "" + ChatColor.RED + ChatColor.ITALIC + "Spider";
		case BabyCow:
			return "" + ChatColor.RED + ChatColor.ITALIC + ChatColor.BOLD + "BabyCow";
		case Bunny:
			return "" + ChatColor.YELLOW + ChatColor.ITALIC + ChatColor.BOLD + "Bunny";
		default:
			// return "" + ChatColor.RESET + "None";
			break;

		}
		return this.toString();
	}
}