package anthony.SuperCraftBrawl.pvp;

import anthony.SuperCraftBrawl.Game.GameState;

public class PvPManager {
	
	public GameState state;
	
	public PvPManager(GameState state) {
		this.state = state;
	}
	
}
