package anthony.SuperCraftBrawl.playerdata;

import java.util.UUID;

public class PlayerData {
	public UUID playerUUID;

	public String playerName, playerIP;

	public int roleID = 0, tokens = 0, wins = 0, kills = 0, deaths = 0, flawlessWins = 0, losses = 0, winstreak = 0, cwm = 0, melon = 0, astronaut = 0,
	pm = 0;

	public PlayerData(UUID playerUUID, String playerName, String playerIP, int roleID, int tokens, int wins, int kills,
			int deaths, int flawlessWins, int losses, int winstreak, int cwm, int melon, int astronaut, int pm) {
		this(playerUUID, playerName, playerIP);
		this.roleID = roleID;
		this.tokens = tokens;
		this.wins = wins;
		this.kills = kills;
		this.deaths = deaths;
		this.flawlessWins = flawlessWins;
		this.losses = losses;
		this.winstreak = winstreak;
		this.cwm = cwm;
		this.melon = melon;
		this.astronaut = astronaut;
		this.pm = pm;
	}

	public PlayerData(UUID playerUUID, String playerName, String playerIP) {
		this.playerUUID = playerUUID;
		this.playerName = playerName;
		this.playerIP = playerIP;

	}
}
