package anthony.SuperCraftBrawl.commands;

import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.ScoreboardManager;

import anthony.SuperCraftBrawl.Main;
import anthony.SuperCraftBrawl.Game.GameInstance;
import anthony.SuperCraftBrawl.Game.GameReason;
import anthony.SuperCraftBrawl.Game.GameState;
import anthony.SuperCraftBrawl.Game.classes.BaseClass;
import anthony.SuperCraftBrawl.Game.classes.ClassType;
import anthony.SuperCraftBrawl.Game.map.Maps;
import anthony.SuperCraftBrawl.playerdata.PlayerData;
import anthony.SuperCraftBrawl.ranks.Rank;

public class Commands implements CommandExecutor {

	private final Main main;
	public List<Player> players;
	public static Inventory inv;
	public static String inventory_name;
	public static int inv_rows = 4 * 9;
	public GameState state;
	public GameReason reason;
	public GameInstance instance;

	public Commands(Main main) {
		this.main = main;
	}

	public void TellAll(String message) {
		for (Player player : players) {
			player.sendMessage(message);
		}
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		Player player = (Player) sender;

		if (sender instanceof Player) {
			switch (cmd.getName().toLowerCase()) {
			case "test":
				sender.sendMessage("test v1.0");
				break;
			case "startgame":
				GameInstance instance2 = main.getGameManager().GetInstanceOfPlayer(player);

				if (player.hasPermission("scb.startGame")) {
					if (instance2.state == GameState.WAITING && instance2.players.size() >= 2) {
						instance2.TellAll("" + ChatColor.BOLD + "(!) " + ChatColor.RESET
								+ "Game has been force started by an Admin");
						instance2.ticksTilStart = 0;
					} else {
						player.sendMessage(
								"" + ChatColor.BOLD + "(!) " + ChatColor.RESET + "Not enough players to start!");
					}
				} else {
					player.sendMessage("" + ChatColor.BOLD + "(!) " + ChatColor.RESET
							+ "You do not have permission to use this command!");
				}
				break;

			case "setlives":
				GameInstance instance22 = main.getGameManager().GetInstanceOfPlayer(player);
				BaseClass baseClass = instance22.classes.get(player);

				if (player.hasPermission("scb.setLives")) {
					if (instance22.state == GameState.STARTED) {
						if (args.length > 0) {
							Player target = Bukkit.getServer().getPlayerExact(args[0]);
							int num = Integer.parseInt(args[1]);

							if (target != null) {
								baseClass.lives = num;
								player.sendMessage("" + ChatColor.RESET + ChatColor.DARK_GREEN + ChatColor.BOLD + "(!) "
										+ ChatColor.RESET + "You have set " + ChatColor.YELLOW + target.getName()
										+ ChatColor.RESET + "'s lives to " + ChatColor.YELLOW + num);
							}
						}
					} else {
						player.sendMessage("" + ChatColor.RESET + ChatColor.DARK_GREEN + ChatColor.BOLD + "(!) "
								+ ChatColor.RESET + "Game must be started in order to use this!");
					}
				}
				break;

			case "setrank":
				if (player.hasPermission("scb.setrank")) {
					if (args.length > 1) {
						Rank rank = Rank.getRankFromName(args[1]);
						Player target = Bukkit.getServer().getPlayerExact(args[0]);
						if (target != null) {
							main.getRankManager().setRank(target, rank);
							player.sendMessage("" + ChatColor.BOLD + "(!) " + ChatColor.RESET + target.getName()
									+ "'s rank was set to " + rank.getTag());
							target.sendMessage("" + ChatColor.BOLD + "(!) " + ChatColor.RESET
									+ "Your rank has been set to " + rank.getTag());
							main.LobbyBoard(target);
						} else {
							player.sendMessage(
									"" + ChatColor.BOLD + "(!) " + ChatColor.RESET + "This player is not online!");
						}
					} else {
						player.sendMessage("" + ChatColor.BOLD + "(!) " + ChatColor.RESET
								+ "Incorrect usage! Try doing: " + ChatColor.GREEN + "/setrank <player> <rank>");
					}
				}
				break;
			case "join":

				if (args.length > 0) {
					String mapName = args[0];

					Maps map = null;
					for (Maps maps : Maps.values()) {
						if (maps.toString().equalsIgnoreCase(mapName)) {
							map = maps;
							break;
						}
					}
					if (map != null) {
						main.getGameManager().JoinMap(player, map);

					} else {
						player.sendMessage(ChatColor.BOLD + "(!) " + ChatColor.RESET + "This map does not exist! Use "
								+ ChatColor.YELLOW + "/maplist " + ChatColor.RESET + "for a list of playable maps");
					}

				} else
					player.sendMessage("" + ChatColor.WHITE + ChatColor.BOLD + "(!) " + ChatColor.RESET
							+ "Incorrect usage! Try doing: " + ChatColor.RESET + ChatColor.GREEN + "/join <mapname>");

				return true;

			case "spectate":
				if (sender instanceof Player) {
					if (args.length > 0) {
						String mapName = args[0];
						Maps map = null;

						for (Maps maps : Maps.values()) {
							if (maps.toString().equalsIgnoreCase(mapName)) {
								map = maps;
								break;
							}
						}

						if (map != null) {
							main.getGameManager().SpectatorJoinMap(player, map);
						}
					} else {
						player.sendMessage("" + ChatColor.WHITE + ChatColor.BOLD + "(!) " + ChatColor.RESET
								+ "Incorrect usage! Try doing: " + ChatColor.RESET + ChatColor.GREEN
								+ "/spectate <mapname>");
					}
				}
				return true;

			/*
			 * case "startgame": if (sender instanceof Player) { if (args.length > 0) {
			 * GameReason result = main.getGameInstance().ForceGameStart(player);
			 * 
			 * switch (result) { case FORCESTARTGAME: player.sendMessage("" + ChatColor.BOLD
			 * + "(!) " + ChatColor.RESET + ChatColor.GREEN + "Game " +
			 * "has been force started by an Admin"); break;
			 * 
			 * case NOT_ENOUGH: player.sendMessage("" + ChatColor.BOLD + "(!) " +
			 * ChatColor.RESET + "Not enough players to start!"); break;
			 * 
			 * case ALREADYPLAYING: player.sendMessage("" + ChatColor.BOLD + "(!) " +
			 * ChatColor.RESET + "This game is already playing!"); break;
			 * 
			 * case FAIL: player.sendMessage("" + ChatColor.BOLD + "(!) " + ChatColor.RESET
			 * + "You must be in a Lobby to use " + ChatColor.GREEN + "/startgame"); }
			 * 
			 * } else player.sendMessage("" + "Incorrect usage!"); } return true;
			 */

			case "class":
				if (sender instanceof Player) {
					if (args.length > 0) {
						String className = args[0];
						for (ClassType type : ClassType.values())
							if (className.equalsIgnoreCase(type.toString())) {
								sender.sendMessage("" + ChatColor.RESET + ChatColor.DARK_GREEN + ChatColor.BOLD + "(!) "
										+ ChatColor.RESET + ChatColor.GREEN + "You have selected " + ChatColor.RESET
										+ ChatColor.BOLD + type.getTag());
								main.getGameManager().playerSelectClass((Player) sender, type);
								return true;
							} /*
								 * else if (className.equalsIgnoreCase("random")) { sender.sendMessage("" +
								 * ChatColor.RESET + ChatColor.DARK_GREEN + ChatColor.BOLD + "(!) " +
								 * ChatColor.RESET + "You have selected to go a Random class");
								 * instance.setClass((Player) sender, null); }
								 */
						sender.sendMessage("" + ChatColor.BOLD + "(!) " + ChatColor.RESET + "This class doesn't exist! "
								+ "Use " + ChatColor.GREEN + "/classes " + ChatColor.RESET + "for classes list");
					} else
						sender.sendMessage(
								"" + ChatColor.BOLD + "(!) " + ChatColor.RESET + "Incorrect usage! Try doing: "
										+ ChatColor.RESET + ChatColor.GREEN + "/class <classname>");
				} else
					sender.sendMessage(ChatColor.RED + "You must be a player to choose a class");
				return true;

			case "spawn":
				if (main.getGameManager().RemovePlayerFromAll(player)) {
					main.ResetPlayer(player);
					ScoreboardManager m = Bukkit.getScoreboardManager();
					Scoreboard c = m.getNewScoreboard();

					Objective o = c.registerNewObjective("Gold", "");
					o.setDisplaySlot(DisplaySlot.SIDEBAR);
					o.setDisplayName("" + ChatColor.YELLOW + ChatColor.BOLD + "MINEZONE");

					Score gold0 = o.getScore("");
					// Score gold = o.getScore(ChatColor.WHITE + "Gold: " + ChatColor.GOLD +
					// "20,000");
					Score gold11 = o.getScore("" + ChatColor.BOLD + "Server: ");
					Score gold12 = o.getScore("Lobby");
					Score gold1 = o.getScore("" + ChatColor.YELLOW + ChatColor.BOLD + "Tokens: ");
					PlayerData data = main.getDataManager().getPlayerData(player);
					Score gold2 = o.getScore("" + ChatColor.WHITE + data.tokens);
					Score gold3 = o.getScore("" + ChatColor.YELLOW + ChatColor.BOLD + "Rank: ");
					Score gold4 = o.getScore("" + ChatColor.GRAY + "Default");
					Score gold5 = o.getScore("" + ChatColor.WHITE + ChatColor.BOLD + "");
					Score gold6 = o.getScore("" + ChatColor.RED + ChatColor.BOLD + "Discord: ");
					Score gold7 = o.getScore("" + ChatColor.WHITE + "discord.gg/B9eHKg7");
					Score gold110 = o.getScore("");
					Score gold111 = o.getScore("");

					// gold11.setScore(11);
					// gold12.setScore(10);
					gold0.setScore(9);
					gold1.setScore(8);
					gold2.setScore(7);
					gold110.setScore(6);
					gold3.setScore(5);
					gold4.setScore(4);
					gold5.setScore(3);
					gold6.setScore(2);
					gold7.setScore(1);

					player.setScoreboard(c);
					player.sendMessage("" + ChatColor.WHITE + ChatColor.BOLD + "(!) " + "You have left your game");

				} else {
					player.sendMessage("" + ChatColor.WHITE + ChatColor.BOLD + "(!) " + "You are not in a game!");

				}
				return true;

			case "leave":
				if (main.getGameManager().RemovePlayerFromAll(player)) {
					main.ResetPlayer(player);
					player.setGameMode(GameMode.ADVENTURE);
					main.LobbyBoard(player);
					main.LobbyItems(player);
					player.sendMessage("" + ChatColor.RESET + ChatColor.DARK_GREEN + ChatColor.BOLD + "(!) "
							+ ChatColor.RESET + "You have left your game");

					player.getInventory().clear();
					player.removePotionEffect(PotionEffectType.SPEED);
					player.removePotionEffect(PotionEffectType.WEAKNESS);
					player.removePotionEffect(PotionEffectType.POISON);
					player.removePotionEffect(PotionEffectType.ABSORPTION);
					player.removePotionEffect(PotionEffectType.BLINDNESS);
					player.removePotionEffect(PotionEffectType.CONFUSION);
					player.removePotionEffect(PotionEffectType.DAMAGE_RESISTANCE);
					player.removePotionEffect(PotionEffectType.FAST_DIGGING);
					player.removePotionEffect(PotionEffectType.FIRE_RESISTANCE);
					player.removePotionEffect(PotionEffectType.HARM);
					player.removePotionEffect(PotionEffectType.HEAL);
					player.removePotionEffect(PotionEffectType.HEALTH_BOOST);
					player.removePotionEffect(PotionEffectType.HUNGER);
					player.removePotionEffect(PotionEffectType.INCREASE_DAMAGE);
					player.removePotionEffect(PotionEffectType.INVISIBILITY);
					player.removePotionEffect(PotionEffectType.JUMP);
					player.removePotionEffect(PotionEffectType.NIGHT_VISION);
					player.removePotionEffect(PotionEffectType.REGENERATION);
					player.removePotionEffect(PotionEffectType.SLOW);
					player.removePotionEffect(PotionEffectType.WATER_BREATHING);
					player.removePotionEffect(PotionEffectType.WITHER);

					player.setGameMode(GameMode.ADVENTURE);

					player.getInventory().setHelmet(new ItemStack(Material.AIR, 1));
					player.getInventory().setChestplate(new ItemStack(Material.AIR, 1));
					player.getInventory().setLeggings(new ItemStack(Material.AIR, 1));
					player.getInventory().setBoots(new ItemStack(Material.AIR, 1));

				} else {
					player.sendMessage("" + ChatColor.RESET + ChatColor.DARK_GREEN + ChatColor.BOLD + "(!) "
							+ ChatColor.RESET + "You are not in a game!");

				}
				return true;

			case "players":
				GameInstance instance = main.getGameManager().GetInstanceOfPlayer(player);
				if (instance != null) {
					String players = "";
					for (Player gamePlayer : instance.players) {
						if (!players.isEmpty())
							players += ", ";
						players += gamePlayer.getName() + "";
					}
					player.sendMessage(
							"" + ChatColor.BOLD + "(!) " + ChatColor.RESET + ChatColor.GREEN + "Players in your game ("
									+ instance.players.size() + "): " + ChatColor.RESET + ChatColor.WHITE);
					player.sendMessage("" + ChatColor.BOLD + "--> " + ChatColor.RESET + players);
				} else
					player.sendMessage("" + ChatColor.BOLD + "(!) " + ChatColor.RESET + "You are not in a game");
				return true;
			case "minecraft:list":
				GameInstance instance3 = main.getGameManager().GetInstanceOfPlayer(player);
				if (instance3 != null) {
					String players = "";
					for (Player gamePlayer : instance3.players) {
						if (!players.isEmpty())
							players += ", ";
						players += gamePlayer.getName() + "";
					}
					player.sendMessage(
							"" + ChatColor.BOLD + "(!) " + ChatColor.RESET + ChatColor.GREEN + "Players in your game ("
									+ instance3.players.size() + "): " + ChatColor.RESET + ChatColor.WHITE);
					player.sendMessage(players);
				} else
					player.sendMessage("" + ChatColor.BOLD + "(!) " + ChatColor.RESET + "You are not in a game");
				return true;
			case "spawntest":
				player.sendMessage("Test");
			}
		} else {
			sender.sendMessage("Hey! You can't use this in the terminal!");
		}
		return true;
	}

}
