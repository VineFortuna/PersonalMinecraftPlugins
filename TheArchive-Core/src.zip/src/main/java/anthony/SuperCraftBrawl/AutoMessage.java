package anthony.SuperCraftBrawl;

public class AutoMessage {

}
